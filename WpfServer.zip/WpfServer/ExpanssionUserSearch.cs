﻿using System.Linq;

namespace WpfServer
{
    public static class ExpanssionUserSearch
    {
        public static bool ReflectionPropertiesSearch<TModel>(this TModel model, string search)
        => typeof(TModel).GetProperties().ToList().Any(property => property.GetValue(model)?.ToString()?.Contains(search) ?? false);
    }
}
