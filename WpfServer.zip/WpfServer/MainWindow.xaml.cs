﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfServer.Models;

namespace WpfServer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public static Ispp0104Context ispp0104Context { get; } = new();
        private List<User> _users;
        public List<User> Users
        {
            get => _users;
            set => OnPropertyChanged(ref _users, value);
        }

        public MainWindow()
        {
            InitializeComponent();

            Users = ispp0104Context.Users.ToList();
            DataContext = this;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyChanged<T>(ref T prope, T value, [CallerMemberName] string prop = "")
        {
            prope = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Users = ispp0104Context.Users.AsEnumerable().Where(user => user.ReflectionPropertiesSearch(((TextBox)sender).Text)).ToList();
        }
        
    }
}
